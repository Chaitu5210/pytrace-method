# pytrace-method
a python tracer to trace methods
